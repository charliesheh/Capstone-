//JQUERY 

$(document).ready(function () {
  $("#Charu").click(function () {
    loadIframe(content-iframe, About-Charu.html);
  });
})