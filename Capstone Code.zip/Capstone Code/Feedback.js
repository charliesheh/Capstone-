document.getElementById('textboxid').style.height="200px";
document.getElementById('textboxid').style.fontSize="14pt";